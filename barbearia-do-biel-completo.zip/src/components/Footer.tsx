import React, { useState } from 'react';
import { Scissors, MapPin, Phone, Clock, ArrowUp, Download, FolderArchive, FileCode, Copy, Check, ExternalLink } from 'lucide-react';
import { SHOP_INFO } from '../data/barbershopData';

export const Footer: React.FC = () => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [downloading, setDownloading] = useState<string | null>(null);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDownload = async (filename: string, displayFilename: string) => {
    setDownloading(filename);
    try {
      const res = await fetch(`/downloads/${filename}`);
      if (!res.ok) throw new Error('Download failed');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = displayFilename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch {
      // Fallback: direct window location
      window.location.href = `/downloads/${filename}`;
    } finally {
      setTimeout(() => setDownloading(null), 1000);
    }
  };

  const handleCopyLink = () => {
    const fullUrl = `${window.location.origin}/downloads/barbearia-do-biel-completo.zip`;
    navigator.clipboard.writeText(fullUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <footer className="bg-[#05080f] border-t border-[#d4af37]/20 pt-16 pb-12 text-slate-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-slate-800">
          {/* Brand Col */}
          <div className="lg:col-span-5">
            <div className="flex items-center gap-3.5 mb-4">
              <div className="relative w-12 h-12 rounded-full overflow-hidden border border-[#d4af37]/60 shadow-md shadow-[#d4af37]/20 shrink-0 bg-black">
                <img
                  src={SHOP_INFO.logo}
                  alt="Barbearia Biel Logo"
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <span className="font-serif text-2xl font-bold tracking-wider text-white">
                  BARBEARIA <span className="text-[#d4af37]">BIEL</span>
                </span>
                <span className="block text-[9px] uppercase tracking-[0.25em] text-[#d4af37]/80 -mt-0.5 font-medium">
                  Tradição & Excelência
                </span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm mb-6">
              A experiência definitiva em corte masculino e barboterapia artesanal. Resgatando o ritual clássico com conforto de alto padrão em São Paulo.
            </p>

            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#0f172a] border border-[#d4af37]/30 text-xs text-[#d4af37]">
              <span>★ 4.9 de avaliação geral no Google</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-3">
            <h4 className="font-serif text-sm font-bold uppercase tracking-widest text-white mb-4">
              Navegação
            </h4>
            <ul className="space-y-2.5 text-xs uppercase tracking-wider">
              <li>
                <a href="#inicio" className="hover:text-[#d4af37] transition-colors">
                  Início
                </a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-[#d4af37] transition-colors">
                  Menu de Serviços & Preços
                </a>
              </li>
              <li>
                <a href="#sobre" className="hover:text-[#d4af37] transition-colors">
                  Nossa Tradição & Equipe
                </a>
              </li>
              <li>
                <a href="#galeria" className="hover:text-[#d4af37] transition-colors">
                  Galeria de Cortes
                </a>
              </li>
              <li>
                <a href="#depoimentos" className="hover:text-[#d4af37] transition-colors">
                  Avaliações de Clientes
                </a>
              </li>
              <li>
                <a href="#contato" className="hover:text-[#d4af37] transition-colors">
                  Agendamento Online
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Details */}
          <div className="lg:col-span-4">
            <h4 className="font-serif text-sm font-bold uppercase tracking-widest text-white mb-4">
              Contato & Local
            </h4>
            <ul className="space-y-3 text-xs text-slate-300">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
                <span>{SHOP_INFO.address} — {SHOP_INFO.city}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#d4af37] shrink-0" />
                <a
                  href={`tel:${SHOP_INFO.phoneRaw}`}
                  className="hover:text-[#d4af37] transition-colors font-semibold"
                >
                  {SHOP_INFO.phoneDisplay}
                </a>
              </li>
              <li className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
                <span>
                  Segunda a Sexta: 10h às 20h<br />
                  Sábado: 08h às 18h<br />
                  Domingo: Fechado
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Download Project ZIP Bar */}
        <div className="py-6 border-b border-slate-800/80 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-center md:text-left">
            <h5 className="text-xs uppercase tracking-widest font-bold text-white flex items-center justify-center md:justify-start gap-2">
              <Download className="w-3.5 h-3.5 text-[#d4af37]" />
              Exportar Projeto para Hospedagem
            </h5>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Baixe os arquivos zip para publicar na Netlify, Lovable, Vercel ou GitHub.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => handleDownload('barbearia-do-biel-completo.zip', 'barbearia-do-biel-codigo-fonte.zip')}
              disabled={downloading === 'barbearia-do-biel-completo.zip'}
              className="inline-flex items-center gap-2 px-3.5 py-2.5 bg-[#0f172a] hover:bg-[#162035] text-slate-200 hover:text-[#d4af37] border border-slate-700 hover:border-[#d4af37] rounded-sm text-xs font-semibold tracking-wider uppercase transition-all shadow-sm cursor-pointer disabled:opacity-50"
              title="Baixar código fonte completo para Lovable ou GitHub"
            >
              <FileCode className="w-3.5 h-3.5 text-[#d4af37]" />
              {downloading === 'barbearia-do-biel-completo.zip' ? 'Baixando...' : 'Código Fonte (Lovable)'}
            </button>

            <button
              onClick={() => handleDownload('barbearia-do-biel-site-pronto.zip', 'barbearia-do-biel-site-pronto.zip')}
              disabled={downloading === 'barbearia-do-biel-site-pronto.zip'}
              className="inline-flex items-center gap-2 px-3.5 py-2.5 bg-gradient-to-r from-[#d4af37] to-[#aa841e] hover:from-[#f5d77f] hover:to-[#d4af37] text-[#05080f] rounded-sm text-xs font-bold tracking-wider uppercase transition-all shadow-md cursor-pointer disabled:opacity-50"
              title="Baixar pasta de produção para arrastar direto no Netlify Drop"
            >
              <FolderArchive className="w-3.5 h-3.5" />
              {downloading === 'barbearia-do-biel-site-pronto.zip' ? 'Baixando...' : 'Site Pronto (Netlify)'}
            </button>

            <button
              onClick={handleCopyLink}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-[#05080f] hover:bg-[#0f172a] text-slate-300 hover:text-white border border-slate-800 rounded-sm text-xs transition-colors cursor-pointer"
              title="Copiar link direto para colar em outra aba do navegador"
            >
              {copiedLink ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400 font-semibold">Link Copiado!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-400" />
                  <span>Copiar Link</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>
            &copy; {new Date().getFullYear()} Barbearia do Biel. Todos os direitos reservados.
          </p>

          <div className="flex items-center gap-4">
            <span className="text-slate-400">
              São Paulo · Brasil
            </span>

            <button
              onClick={scrollToTop}
              className="p-2 rounded-sm bg-[#0f172a] hover:bg-[#d4af37] hover:text-[#05080f] text-slate-300 border border-slate-800 transition-colors"
              aria-label="Voltar ao topo"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
