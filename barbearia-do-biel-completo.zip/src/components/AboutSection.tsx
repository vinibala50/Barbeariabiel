import React from 'react';
import { BARBERS, SHOP_INFO } from '../data/barbershopData';
import { Star, ShieldCheck, Award, Scissors, Users } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="sobre" className="py-24 relative bg-[#0a0f1d] border-y border-[#d4af37]/15">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main About Row */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center mb-20">
          {/* Visual with Badge */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-sm overflow-hidden border border-[#d4af37]/40 shadow-2xl group">
              <img
                src="/assets/aistudio/A4E2D970-4905-4987-9436-5E63BBBD7BAB_3adc724b.png"
                alt="Espaço e ambiente real da Barbearia do Biel"
                className="w-full h-[460px] sm:h-[520px] object-cover object-center group-hover:scale-102 transition-transform duration-700"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#05080f]/70 via-transparent to-transparent pointer-events-none" />
            </div>

            {/* Floating Badge */}
            <div className="absolute -bottom-6 -right-2 sm:-right-6 bg-[#0f172a] border border-[#d4af37]/50 p-5 rounded-sm shadow-2xl backdrop-blur-md flex items-center gap-4">
              <div className="w-14 h-14 rounded-full overflow-hidden border border-[#d4af37]/60 shadow-lg shrink-0 bg-black">
                <img
                  src={SHOP_INFO.logo}
                  alt="Barbearia Biel Selo"
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-serif text-3xl sm:text-4xl font-extrabold text-[#d4af37]">
                    {SHOP_INFO.rating}
                  </span>
                  <div className="flex text-[#d4af37]">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#d4af37]" />
                    ))}
                  </div>
                </div>
                <p className="text-[11px] uppercase tracking-wider text-slate-300 font-semibold">
                  Avaliação dos Clientes
                </p>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Mais de 10.000 atendimentos realizados
                </p>
              </div>
            </div>
          </div>

          {/* Text Content */}
          <div className="lg:col-span-7">
            <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.3em] font-semibold text-[#d4af37] mb-3">
              <span className="w-8 h-px bg-[#d4af37]" />
              Mestres da Navalha
            </div>

            <h2 className="font-serif text-3xl sm:text-5xl font-bold text-white tracking-tight leading-tight mb-6">
              Excelência forjada no tempo
            </h2>

            <p className="text-slate-300 text-base sm:text-lg leading-relaxed mb-6 font-light">
              Na <strong className="text-white font-semibold">Barbearia do Biel</strong>, transformamos o hábito diário de corte em uma experiência singular de bem-estar. Cada traço é planejado e executado com rigor estético, resgatando a hospitalidade e a compostura das barbearias clássicas mundiais.
            </p>

            <p className="text-slate-400 text-sm leading-relaxed mb-10">
              Localizada na tradicional Avenida Guilherme Mankel, 630, nossa barbearia combina as técnicas tradicionais da máquina, tesoura e navalha afiada com precisão e hospitalidade. Cada cliente recebe atendimento personalizado e atenção milimétrica.
            </p>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 pt-8 border-t border-slate-800">
              <div>
                <span className="font-serif text-3xl sm:text-4xl font-extrabold text-[#d4af37] block">
                  12
                </span>
                <span className="text-xs uppercase tracking-wider text-slate-400 mt-1 block font-medium">
                  Anos de Tradição
                </span>
              </div>

              <div>
                <span className="font-serif text-3xl sm:text-4xl font-extrabold text-[#d4af37] block">
                  10k+
                </span>
                <span className="text-xs uppercase tracking-wider text-slate-400 mt-1 block font-medium">
                  Clientes Atendidos
                </span>
              </div>

              <div>
                <span className="font-serif text-3xl sm:text-4xl font-extrabold text-[#d4af37] block">
                  Gabriel
                </span>
                <span className="text-xs uppercase tracking-wider text-slate-400 mt-1 block font-medium">
                  Fundador Dedicado
                </span>
              </div>

              <div>
                <span className="font-serif text-3xl sm:text-4xl font-extrabold text-[#d4af37] block">
                  4.9 ★
                </span>
                <span className="text-xs uppercase tracking-wider text-slate-400 mt-1 block font-medium">
                  Satisfação Comprovada
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Founder Showcase */}
        <div className="mt-16 pt-12 border-t border-slate-800/80">
          <div className="text-center max-w-xl mx-auto mb-10">
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white mb-2">
              Fundador & Especialista
            </h3>
            <p className="text-xs sm:text-sm text-slate-400">
              Atendimento exclusivo e corte personalizado conduzido diretamente pelo fundador.
            </p>
          </div>

          <div className="max-w-md mx-auto">
            {BARBERS.map((barber) => (
              <div
                key={barber.id}
                className="bg-[#0f172a] border border-[#d4af37]/30 hover:border-[#d4af37] rounded-sm p-8 flex flex-col items-center text-center transition-all duration-300 shadow-2xl group"
              >
                <div className="w-44 h-44 sm:w-52 sm:h-52 rounded-full overflow-hidden border-2 border-[#d4af37] mb-5 p-1.5 bg-[#162035] group-hover:scale-105 transition-all shadow-xl shadow-[#d4af37]/20">
                  <img
                    src={barber.photo}
                    alt={barber.name}
                    className="w-full h-full object-cover object-[center_15%] rounded-full"
                    loading="lazy"
                  />
                </div>

                <h4 className="font-serif text-2xl font-bold text-white group-hover:text-[#d4af37] transition-colors">
                  {barber.name}
                </h4>

                <span className="inline-block px-3 py-1 bg-[#d4af37]/15 border border-[#d4af37]/40 text-[#f5d77f] text-xs font-bold tracking-widest uppercase rounded-full mt-2 mb-3">
                  {barber.role}
                </span>

                <p className="text-sm text-slate-300 leading-relaxed mb-5 max-w-xs">
                  {barber.specialty}
                </p>

                <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-[#05080f] rounded-full text-xs text-slate-200 border border-slate-800">
                  <Scissors className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>{barber.experience} de maestria na navalha</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
