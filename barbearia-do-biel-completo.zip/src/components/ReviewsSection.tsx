import React, { useState, useEffect } from 'react';
import { INITIAL_REVIEWS, SHOP_INFO } from '../data/barbershopData';
import { Review } from '../types';
import { ReviewModal } from './ReviewModal';
import { Star, CheckCircle, MessageSquarePlus, Quote } from 'lucide-react';

export const ReviewsSection: React.FC = () => {
  const [reviews, setReviews] = useState<Review[]>(() => {
    try {
      const saved = localStorage.getItem('biel_barber_reviews_v4');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // fallback
    }
    return INITIAL_REVIEWS;
  });

  const [modalOpen, setModalOpen] = useState(false);

  const handleAddReview = (newRev: Review) => {
    const updated = [newRev, ...reviews];
    setReviews(updated);
    try {
      localStorage.setItem('biel_barber_reviews_v4', JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  return (
    <section id="depoimentos" className="py-24 relative bg-[#0a0f1d] border-t border-[#d4af37]/15">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.3em] font-semibold text-[#d4af37] mb-3">
              <span className="w-8 h-px bg-[#d4af37]" />
              Depoimentos Verificados
            </div>
            <h2 className="font-serif text-3xl sm:text-5xl font-bold text-white tracking-tight">
              O que dizem nossos <span className="gold-gradient-text">Clientes</span>
            </h2>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="flex items-center gap-1.5 justify-end text-[#d4af37]">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-[#d4af37]" />
                ))}
                <span className="font-serif font-bold text-lg text-white ml-1">4.9 / 5.0</span>
              </div>
              <span className="text-[11px] text-slate-400">Baseado em +10.000 clientes</span>
            </div>

            <button
              onClick={() => setModalOpen(true)}
              className="px-4 py-2.5 bg-[#0f172a] hover:bg-[#162035] text-[#d4af37] border border-[#d4af37]/40 hover:border-[#d4af37] text-xs uppercase tracking-wider font-bold rounded-sm transition-all flex items-center gap-2 shadow-sm"
            >
              <MessageSquarePlus className="w-4 h-4" />
              Avaliar
            </button>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {reviews.slice(0, 8).map((rev) => (
            <div
              key={rev.id}
              className="bg-[#0f172a] border border-slate-800 hover:border-[#d4af37]/30 rounded-sm p-6 flex flex-col justify-between transition-all hover:-translate-y-1 group"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex text-[#d4af37]">
                    {[...Array(rev.rating)].map((_, idx) => (
                      <Star key={idx} className="w-3.5 h-3.5 fill-[#d4af37]" />
                    ))}
                  </div>
                  <Quote className="w-5 h-5 text-slate-700 group-hover:text-[#d4af37]/40 transition-colors" />
                </div>

                <p className="text-slate-300 text-xs sm:text-sm leading-relaxed mb-6 font-light">
                  "{rev.comment}"
                </p>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white group-hover:text-[#d4af37] transition-colors">
                    {rev.author}
                  </h4>
                  <span className="text-[10px] text-slate-500 block">{rev.date}</span>
                </div>

                {rev.verified && (
                  <span className="inline-flex items-center gap-1 text-[10px] text-[#d4af37] font-medium bg-[#05080f] px-2 py-0.5 rounded-full border border-slate-800">
                    <CheckCircle className="w-2.5 h-2.5" />
                    Verificado
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>

        <ReviewModal
          isOpen={modalOpen}
          onClose={() => setModalOpen(false)}
          onSubmitReview={handleAddReview}
        />
      </div>
    </section>
  );
};
