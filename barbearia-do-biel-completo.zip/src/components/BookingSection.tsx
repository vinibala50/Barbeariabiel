import React, { useState, useEffect } from 'react';
import { SERVICES, BARBERS, TIME_SLOTS, SHOP_INFO } from '../data/barbershopData';
import { Service } from '../types';
import {
  Calendar,
  Clock,
  User,
  Scissors,
  MapPin,
  Phone,
  MessageSquare,
  Check,
  Copy,
  ExternalLink,
  Sparkles,
  AlertCircle
} from 'lucide-react';

interface BookingSectionProps {
  selectedServicePreload?: Service | null;
}

export const BookingSection: React.FC<BookingSectionProps> = ({ selectedServicePreload }) => {
  const today = new Date().toISOString().split('T')[0];

  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [serviceId, setServiceId] = useState<string>(SERVICES[0].id);
  const [barberId, setBarberId] = useState<string>('gabriel');
  const [preferredDate, setPreferredDate] = useState<string>(today);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('10:30');
  const [notes, setNotes] = useState('');
  const [copied, setCopied] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);

  // Sync when user clicks "Reservar" on a service card elsewhere on the page
  useEffect(() => {
    if (selectedServicePreload) {
      setServiceId(selectedServicePreload.id);
      const el = document.getElementById('contato');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [selectedServicePreload]);

  const activeService = SERVICES.find((s) => s.id === serviceId) || SERVICES[0];
  const activeBarber = BARBERS.find((b) => b.id === barberId) || BARBERS[0];

  // Format date for the message (DD/MM/YYYY)
  const formatFriendlyDate = (dateStr: string) => {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      return `${parts[2]}/${parts[1]}/${parts[0]}`;
    }
    return dateStr;
  };

  // Generate formatted WhatsApp text
  const generateWhatsAppMessage = () => {
    const formattedDate = formatFriendlyDate(preferredDate);
    const barberText = activeBarber ? `${activeBarber.name} (${activeBarber.role})` : 'Gabriel (Fundador)';
    
    let text = `Olá, Barbearia do Biel! Meu nome é *${clientName.trim() || 'Cliente'}*.\n\n`;
    text += `✂️ Gostaria de agendar: *${activeService.name}* (R$ ${activeService.price})\n`;
    text += `💈 Barbeiro: *${barberText}*\n`;
    text += `📅 Data: *${formattedDate}*\n`;
    text += `⏰ Horário de preferência: *${selectedTimeSlot}*\n`;
    
    if (clientPhone.trim()) {
      text += `📱 Meu WhatsApp de contato: *${clientPhone.trim()}*\n`;
    }
    if (notes.trim()) {
      text += `📝 Observações: ${notes.trim()}\n`;
    }
    text += `\nAguardo a confirmação da disponibilidade. Obrigado!`;
    return text;
  };

  const messageText = generateWhatsAppMessage();
  const whatsappUrl = `https://wa.me/${SHOP_INFO.phoneRaw}?text=${encodeURIComponent(messageText)}`;

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(messageText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName.trim()) {
      const input = document.getElementById('clientNameInput');
      input?.focus();
      return;
    }
    setShowConfirmation(true);
  };

  return (
    <section id="contato" className="py-24 relative bg-[#05080f]">
      {/* Decorative top line */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#d4af37]/30 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#0f172a] border border-[#d4af37]/25 rounded-sm p-6 sm:p-10 lg:p-14 shadow-2xl relative overflow-hidden">
          {/* Subtle gold glow */}
          <div className="absolute -top-24 -right-24 w-80 h-80 bg-[#d4af37]/5 rounded-full blur-3xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14">
            {/* Left: Info & Contacts */}
            <div className="lg:col-span-5 flex flex-col justify-between">
              <div>
                <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.3em] font-semibold text-[#d4af37] mb-3">
                  <span className="w-8 h-px bg-[#d4af37]" />
                  Agendamento & Local
                </div>

                <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight leading-tight mb-5">
                  Garanta seu horário com <span className="gold-gradient-text">facilidade</span>
                </h2>

                <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-8 font-light">
                  Prefere agendamento imediato? Preencha o formulário para enviar os detalhes diretamente ao nosso WhatsApp ou fale conosco em um toque.
                </p>

                {/* Contact Cards */}
                <div className="space-y-6">
                  {/* Address */}
                  <div className="flex items-start gap-4 p-4 bg-[#05080f]/80 rounded-sm border border-slate-800">
                    <div className="w-11 h-11 rounded-sm border border-[#d4af37]/40 bg-[#162035] flex items-center justify-center text-[#d4af37] shrink-0">
                      <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold block">
                        Endereço
                      </span>
                      <p className="text-sm font-semibold text-white mt-0.5">
                        {SHOP_INFO.address}
                      </p>
                      <p className="text-xs text-slate-400">
                        {SHOP_INFO.city} • Estacionamento nas imediações
                      </p>
                    </div>
                  </div>

                  {/* Phone / WhatsApp */}
                  <div className="flex items-start gap-4 p-4 bg-[#05080f]/80 rounded-sm border border-slate-800">
                    <div className="w-11 h-11 rounded-sm border border-[#d4af37]/40 bg-[#162035] flex items-center justify-center text-[#d4af37] shrink-0">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold block">
                        Telefone & WhatsApp
                      </span>
                      <a
                        href={`https://wa.me/${SHOP_INFO.phoneRaw}?text=Ol%C3%A1%2C%20gostaria%20de%20agendar%20um%20hor%C3%A1rio%20na%20Barbearia%20do%20Biel.`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-base font-bold text-[#d4af37] hover:underline underline-offset-4 mt-0.5 block"
                      >
                        {SHOP_INFO.phoneDisplay}
                      </a>
                      <p className="text-xs text-slate-400">
                        Resposta rápida em horário comercial
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Service Preview Summary Box */}
              <div className="mt-8 p-5 bg-[#05080f] rounded-sm border border-[#d4af37]/30">
                <div className="flex items-center justify-between text-xs text-slate-400 uppercase tracking-wider mb-2">
                  <span>Resumo do Agendamento</span>
                  <span className="text-[#d4af37] font-semibold">{activeService.name}</span>
                </div>
                <div className="flex items-baseline justify-between pt-2 border-t border-slate-800">
                  <div className="text-xs text-slate-300">
                    Tempo estimado: <span className="text-white font-medium">~{activeService.durationMinutes} min</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 uppercase block">Total</span>
                    <span className="font-serif text-2xl font-bold text-[#d4af37]">
                      R$ {activeService.price}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Booking Form */}
            <div className="lg:col-span-7">
              <form onSubmit={handleSubmit} className="space-y-5">
                {/* Client Name */}
                <div>
                  <label
                    htmlFor="clientNameInput"
                    className="block text-xs uppercase tracking-wider font-semibold text-[#f5d77f] mb-1.5"
                  >
                    Seu Nome Completo *
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                      <User className="w-4 h-4 text-[#d4af37]" />
                    </div>
                    <input
                      id="clientNameInput"
                      type="text"
                      required
                      value={clientName}
                      onChange={(e) => setClientName(e.target.value)}
                      placeholder="Ex: Lucas Mendes"
                      className="w-full bg-[#05080f] border border-slate-700/80 focus:border-[#d4af37] pl-10 pr-4 py-3 rounded-sm text-sm text-white focus:outline-none focus:ring-1 focus:ring-[#d4af37] transition-all"
                    />
                  </div>
                </div>

                {/* Service & Barber Selection Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Service */}
                  <div>
                    <label
                      htmlFor="serviceSelect"
                      className="block text-xs uppercase tracking-wider font-semibold text-[#f5d77f] mb-1.5"
                    >
                      Serviço Desejado *
                    </label>
                    <div className="relative">
                      <select
                        id="serviceSelect"
                        value={serviceId}
                        onChange={(e) => setServiceId(e.target.value)}
                        className="w-full bg-[#05080f] border border-slate-700/80 focus:border-[#d4af37] px-3.5 py-3 rounded-sm text-sm text-white focus:outline-none focus:ring-1 focus:ring-[#d4af37] appearance-none cursor-pointer"
                      >
                        {SERVICES.map((s) => (
                          <option key={s.id} value={s.id} className="bg-[#0f172a] text-white">
                            {s.name} — R$ {s.price}
                          </option>
                        ))}
                      </select>
                      <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                        <Scissors className="w-4 h-4 text-[#d4af37]" />
                      </div>
                    </div>
                  </div>

                  {/* Barber */}
                  <div>
                    <label
                      htmlFor="barberSelect"
                      className="block text-xs uppercase tracking-wider font-semibold text-[#f5d77f] mb-1.5"
                    >
                      Profissional
                    </label>
                    <select
                      id="barberSelect"
                      value={barberId}
                      onChange={(e) => setBarberId(e.target.value)}
                      className="w-full bg-[#05080f] border border-slate-700/80 focus:border-[#d4af37] px-3.5 py-3 rounded-sm text-sm text-white focus:outline-none focus:ring-1 focus:ring-[#d4af37] appearance-none cursor-pointer"
                    >
                      {BARBERS.map((b) => (
                        <option key={b.id} value={b.id} className="bg-[#0f172a] text-white">
                          {b.name} ({b.role})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Date & Contact Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Date */}
                  <div>
                    <label
                      htmlFor="preferredDate"
                      className="block text-xs uppercase tracking-wider font-semibold text-[#f5d77f] mb-1.5"
                    >
                      Data de Preferência *
                    </label>
                    <div className="relative">
                      <input
                        id="preferredDate"
                        type="date"
                        min={today}
                        required
                        value={preferredDate}
                        onChange={(e) => setPreferredDate(e.target.value)}
                        className="w-full bg-[#05080f] border border-slate-700/80 focus:border-[#d4af37] px-3.5 py-3 rounded-sm text-sm text-white focus:outline-none focus:ring-1 focus:ring-[#d4af37] cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Phone */}
                  <div>
                    <label
                      htmlFor="clientPhoneInput"
                      className="block text-xs uppercase tracking-wider font-semibold text-[#f5d77f] mb-1.5"
                    >
                      Seu WhatsApp (Opcional)
                    </label>
                    <input
                      id="clientPhoneInput"
                      type="tel"
                      value={clientPhone}
                      onChange={(e) => setClientPhone(e.target.value)}
                      placeholder="(11) 90000-0000"
                      className="w-full bg-[#05080f] border border-slate-700/80 focus:border-[#d4af37] px-3.5 py-3 rounded-sm text-sm text-white focus:outline-none focus:ring-1 focus:ring-[#d4af37]"
                    />
                  </div>
                </div>

                {/* Time Slots Selection */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs uppercase tracking-wider font-semibold text-[#f5d77f]">
                      Horário de Preferência
                    </label>
                    <span className="text-[11px] text-slate-400">
                      Selecionado: <strong className="text-[#d4af37]">{selectedTimeSlot}</strong>
                    </span>
                  </div>

                  <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                    {TIME_SLOTS.map((slot) => (
                      <button
                        type="button"
                        key={slot}
                        onClick={() => setSelectedTimeSlot(slot)}
                        className={`py-2 text-xs font-semibold rounded-xs border transition-all ${
                          selectedTimeSlot === slot
                            ? 'bg-[#d4af37] text-[#05080f] border-[#d4af37] font-bold shadow-md shadow-[#d4af37]/20 scale-102'
                            : 'bg-[#05080f] text-slate-300 border-slate-800 hover:border-slate-600 hover:text-white'
                        }`}
                      >
                        {slot}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Notes */}
                <div>
                  <label
                    htmlFor="clientNotes"
                    className="block text-xs uppercase tracking-wider font-semibold text-[#f5d77f] mb-1.5"
                  >
                    Observações ou Preferências Especiais
                  </label>
                  <textarea
                    id="clientNotes"
                    rows={2}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Ex: Prefiro atendimento silencioso, referência de degradê da foto 2, etc."
                    className="w-full bg-[#05080f] border border-slate-700/80 focus:border-[#d4af37] px-3.5 py-2.5 rounded-sm text-sm text-white focus:outline-none focus:ring-1 focus:ring-[#d4af37]"
                  />
                </div>

                {/* Action Buttons */}
                <div className="pt-3 space-y-3">
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => setShowConfirmation(true)}
                    className="w-full py-4 bg-gradient-to-r from-[#d4af37] via-[#e6c761] to-[#aa841e] hover:from-[#e6c761] hover:to-[#aa841e] text-[#05080f] font-bold text-sm uppercase tracking-wider rounded-sm shadow-xl flex items-center justify-center gap-2.5 transition-all group"
                  >
                    <MessageSquare className="w-5 h-5 text-[#05080f]" />
                    <span>Confirmar via WhatsApp</span>
                    <ExternalLink className="w-4 h-4 text-[#05080f] group-hover:translate-x-0.5 transition-transform" />
                  </a>

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                    <button
                      type="button"
                      onClick={handleCopyMessage}
                      className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-[#d4af37] py-1 transition-colors"
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400 font-semibold">Mensagem copiada para a área de transferência!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copiar texto formatado do agendamento</span>
                        </>
                      )}
                    </button>

                    <span className="text-[11px] text-slate-500">
                      Atendimento rápido e sem burocracia
                    </span>
                  </div>
                </div>

                {/* Success Preview Modal / Notification */}
                {showConfirmation && (
                  <div className="mt-4 p-4 bg-[#0a1426] border border-[#d4af37]/40 rounded-sm animate-in fade-in">
                    <div className="flex items-start gap-3">
                      <Sparkles className="w-5 h-5 text-[#d4af37] shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-sm font-bold text-white">
                          Mensagem de Agendamento Pronta!
                        </h4>
                        <p className="text-xs text-slate-300 mt-1">
                          Caso a janela do WhatsApp não tenha aberto automaticamente, clique no botão acima ou copie a mensagem e envie para o número <strong className="text-[#d4af37]">(11) 98303-6194</strong>.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
