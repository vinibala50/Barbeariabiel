import React, { useState } from 'react';
import { X, Star, CheckCircle } from 'lucide-react';
import { Review } from '../types';

interface ReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitReview: (review: Review) => void;
}

export const ReviewModal: React.FC<ReviewModalProps> = ({
  isOpen,
  onClose,
  onSubmitReview,
}) => {
  const [author, setAuthor] = useState('');
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!author.trim() || !comment.trim()) return;

    const newReview: Review = {
      id: 'rev-' + Date.now(),
      author: author.trim(),
      rating,
      date: 'Agora mesmo',
      comment: comment.trim(),
      verified: true,
    };

    onSubmitReview(newReview);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setAuthor('');
      setComment('');
      setRating(5);
      onClose();
    }, 1500);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative max-w-lg w-full bg-[#0f172a] border border-[#d4af37]/40 rounded-sm p-6 sm:p-8 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1"
          aria-label="Fechar"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="py-8 text-center flex flex-col items-center">
            <CheckCircle className="w-14 h-14 text-[#d4af37] mb-3 animate-bounce" />
            <h3 className="font-serif text-2xl font-bold text-white mb-2">
              Muito obrigado pela avaliação!
            </h3>
            <p className="text-xs text-slate-300">
              Sua opinião ajuda a Barbearia do Biel a manter o padrão máximo de excelência.
            </p>
          </div>
        ) : (
          <div>
            <div className="text-center mb-6">
              <span className="text-[10px] uppercase tracking-[0.25em] text-[#d4af37] font-semibold block mb-1">
                Sua Experiência
              </span>
              <h3 className="font-serif text-2xl font-bold text-white">
                Avaliar a Barbearia do Biel
              </h3>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-slate-300 font-semibold mb-1.5">
                  Sua Nota
                </label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      type="button"
                      key={star}
                      onMouseEnter={() => setHoverRating(star)}
                      onMouseLeave={() => setHoverRating(0)}
                      onClick={() => setRating(star)}
                      className="p-1 focus:outline-none transition-transform hover:scale-125"
                    >
                      <Star
                        className={`w-7 h-7 ${
                          (hoverRating || rating) >= star
                            ? 'fill-[#d4af37] text-[#d4af37]'
                            : 'text-slate-600'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="text-xs text-[#d4af37] font-bold ml-2">
                    {rating} de 5 estrelas
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-slate-300 font-semibold mb-1.5">
                  Seu Nome
                </label>
                <input
                  type="text"
                  required
                  value={author}
                  onChange={(e) => setAuthor(e.target.value)}
                  placeholder="Ex: Gabriel Moreira"
                  className="w-full bg-[#05080f] border border-slate-700 focus:border-[#d4af37] px-4 py-2.5 rounded-sm text-sm text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs uppercase tracking-wider text-slate-300 font-semibold mb-1.5">
                  Seu Comentário
                </label>
                <textarea
                  required
                  rows={4}
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Conte o que achou do atendimento, corte, barba ou ambiente..."
                  className="w-full bg-[#05080f] border border-slate-700 focus:border-[#d4af37] px-4 py-2.5 rounded-sm text-sm text-white focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-[#d4af37] to-[#aa841e] text-[#05080f] font-bold text-xs uppercase tracking-wider rounded-sm shadow-md hover:scale-[1.01] active:scale-98 transition-all mt-2"
              >
                Publicar Avaliação
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
