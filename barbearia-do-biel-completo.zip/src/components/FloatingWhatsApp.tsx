import React, { useState } from 'react';
import { MessageSquare, X, ArrowUpRight } from 'lucide-react';
import { SHOP_INFO } from '../data/barbershopData';

export const FloatingWhatsApp: React.FC = () => {
  const [tooltipVisible, setTooltipVisible] = useState(true);

  const defaultMessage = encodeURIComponent(
    'Olá! Gostaria de tirar uma dúvida ou verificar horários disponíveis na Barbearia do Biel.'
  );
  const whatsappUrl = `https://wa.me/${SHOP_INFO.phoneRaw}?text=${defaultMessage}`;

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
      {tooltipVisible && (
        <div className="mb-2 bg-[#0f172a] border border-[#d4af37]/40 shadow-2xl p-3 rounded-sm text-xs text-white max-w-[230px] relative animate-in fade-in slide-in-from-bottom-2">
          <button
            onClick={() => setTooltipVisible(false)}
            className="absolute top-1 right-1 text-slate-400 hover:text-white p-0.5"
            aria-label="Fechar aviso"
          >
            <X className="w-3.5 h-3.5" />
          </button>
          <p className="font-semibold text-[#d4af37] text-[11px] uppercase tracking-wider mb-0.5">
            Agendamento Rápido
          </p>
          <p className="text-[11px] text-slate-300">
            Dúvidas ou agendamento direto? Fale conosco no WhatsApp!
          </p>
        </div>
      )}

      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="w-14 h-14 rounded-full bg-gradient-to-tr from-[#128C7E] to-[#25D366] text-white shadow-2xl hover:scale-110 active:scale-95 transition-all flex items-center justify-center relative group border-2 border-emerald-300/40"
        aria-label="Abrir WhatsApp da Barbearia do Biel"
      >
        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-[#d4af37] rounded-full border-2 border-[#05080f] animate-ping" />
        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-[#d4af37] rounded-full border-2 border-[#05080f]" />
        
        {/* WhatsApp Icon */}
        <svg className="w-7 h-7 fill-white" viewBox="0 0 24 24">
          <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.77-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.312.045-.694.062-2.126-.53-1.832-.757-3.003-2.617-3.094-2.738-.091-.122-.746-.992-.746-1.892 0-.9.472-1.344.64-1.528.168-.184.368-.231.49-.231.123 0 .245.001.352.006.113.006.264-.043.413.315.153.366.524 1.278.57 1.37.046.092.077.2.015.323-.062.123-.092.2-.184.307-.092.108-.194.24-.277.323-.092.092-.188.192-.081.376.107.184.477.786 1.023 1.272.704.628 1.297.823 1.481.915.185.092.292.077.4-.046.108-.123.461-.537.584-.722.123-.184.246-.153.415-.092.169.061 1.075.507 1.259.6.184.092.307.138.353.215.046.077.046.445-.098.85z" />
        </svg>
      </a>
    </div>
  );
};
