import React from 'react';
import { X, ZoomIn, Calendar } from 'lucide-react';
import { GalleryItem } from '../types';

interface ImageLightboxModalProps {
  item: GalleryItem | null;
  onClose: () => void;
  onBookStyle: (item: GalleryItem) => void;
}

export const ImageLightboxModal: React.FC<ImageLightboxModalProps> = ({
  item,
  onClose,
  onBookStyle,
}) => {
  if (!item) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative max-w-4xl w-full bg-[#0f172a] border border-[#d4af37]/40 rounded-sm overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-[#05080f]/80 text-white hover:text-[#d4af37] border border-slate-700 hover:border-[#d4af37] flex items-center justify-center transition-all"
          aria-label="Fechar modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 max-h-[85vh]">
          <div className="md:col-span-8 bg-black flex items-center justify-center overflow-hidden max-h-[50vh] md:max-h-[85vh]">
            <img
              src={item.image}
              alt={item.title}
              className="w-full h-full object-cover md:object-contain"
            />
          </div>

          <div className="md:col-span-4 p-6 sm:p-8 flex flex-col justify-between overflow-y-auto">
            <div>
              <div className="inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.25em] font-semibold text-[#d4af37] mb-2">
                <span>Coleção Exclusiva</span>
              </div>

              <h3 className="font-serif text-2xl font-bold text-white mb-3">
                {item.title}
              </h3>

              <p className="text-slate-300 text-sm leading-relaxed mb-6 font-light">
                {item.description}
              </p>

              <div className="p-4 bg-[#05080f] border border-slate-800 rounded-sm mb-6 text-xs text-slate-400 space-y-2">
                <p className="flex items-center justify-between">
                  <span>Técnica:</span>
                  <span className="text-white font-medium">Navalhete + Tesoura Japonesa</span>
                </p>
                <p className="flex items-center justify-between">
                  <span>Acabamento:</span>
                  <span className="text-white font-medium">Pomada Matte & Óleo Nutritivo</span>
                </p>
                <p className="flex items-center justify-between">
                  <span>Duração Estimada:</span>
                  <span className="text-[#d4af37] font-semibold">45 a 60 minutos</span>
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex flex-col gap-2">
              <button
                onClick={() => {
                  onClose();
                  onBookStyle(item);
                }}
                className="w-full py-3 bg-[#d4af37] hover:bg-[#aa841e] text-[#05080f] font-bold text-xs uppercase tracking-wider rounded-sm shadow-md transition-all flex items-center justify-center gap-2"
              >
                <Calendar className="w-4 h-4" />
                Quero Este Estilo
              </button>

              <button
                onClick={onClose}
                className="w-full py-2.5 bg-transparent text-slate-400 hover:text-white text-xs uppercase tracking-wider font-semibold transition-colors"
              >
                Voltar à Galeria
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
