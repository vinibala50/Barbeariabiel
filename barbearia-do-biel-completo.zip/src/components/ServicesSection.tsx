import React, { useState } from 'react';
import { SERVICES } from '../data/barbershopData';
import { Service } from '../types';
import { Clock, Check, Sparkles, ArrowRight, Coffee, Wifi, Droplets } from 'lucide-react';

interface ServicesSectionProps {
  onSelectService: (service: Service) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectService }) => {
  const [activeCategory, setActiveCategory] = useState<string>('todos');

  const categories = [
    { id: 'todos', label: 'Todos os Serviços' },
    { id: 'corte', label: 'Cortes' },
    { id: 'barba', label: 'Barba' },
    { id: 'combo', label: 'Combos Especiais' },
  ];

  const filteredServices = activeCategory === 'todos'
    ? SERVICES
    : SERVICES.filter((s) => s.category === activeCategory);

  return (
    <section id="servicos" className="py-24 relative bg-[#05080f]">
      {/* Decorative background divider */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#d4af37]/30 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.3em] font-semibold text-[#d4af37] mb-3">
              <span className="w-8 h-px bg-[#d4af37]" />
              Menu Exclusivo
            </div>
            <h2 className="font-serif text-3xl sm:text-5xl font-bold text-white tracking-tight">
              Nossos <span className="gold-gradient-text">Serviços</span>
            </h2>
          </div>
          <p className="text-slate-400 max-w-md text-sm sm:text-base leading-relaxed">
            Cada serviço é executado com rigor técnico, produtos importados de alta performance e a hospitalidade tradicional da navalha clássica.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-10 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-5 py-2.5 text-xs uppercase tracking-wider font-semibold rounded-sm whitespace-nowrap transition-all ${
                activeCategory === cat.id
                  ? 'bg-[#d4af37] text-[#05080f] shadow-lg shadow-[#d4af37]/20 font-bold'
                  : 'bg-[#0f172a] text-slate-300 hover:text-white hover:bg-[#162035] border border-slate-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredServices.map((service) => (
            <div
              key={service.id}
              className="group bg-[#0f172a] border border-[#d4af37]/15 hover:border-[#d4af37]/50 rounded-sm overflow-hidden flex flex-col transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-[#05080f]"
            >
              {/* Image preview with gradient vignette */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={service.image}
                  alt={service.name}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 filter contrast-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0f172a] via-[#0f172a]/20 to-transparent" />

                {service.popular && (
                  <div className="absolute top-3 right-3 px-3 py-1 bg-gradient-to-r from-[#d4af37] to-[#aa841e] text-[#05080f] text-[10px] font-extrabold uppercase tracking-widest rounded-xs shadow-md">
                    Mais Pedido
                  </div>
                )}

                <div className="absolute bottom-3 left-4 flex items-center gap-1.5 text-xs text-slate-300 bg-[#05080f]/80 backdrop-blur-sm px-2.5 py-1 rounded-sm border border-slate-700/60">
                  <Clock className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>~{service.durationMinutes} min</span>
                </div>
              </div>

              {/* Service details */}
              <div className="p-6 flex flex-col flex-1 justify-between">
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="font-serif text-xl font-bold text-white group-hover:text-[#d4af37] transition-colors">
                      {service.name}
                    </h3>
                  </div>

                  <p className="text-slate-400 text-xs sm:text-sm leading-relaxed mb-6">
                    {service.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase tracking-wider text-slate-400 block font-medium">Valor</span>
                    <span className="font-serif text-2xl font-bold text-[#d4af37]">
                      R$ {service.price}
                    </span>
                  </div>

                  <button
                    onClick={() => onSelectService(service)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#162035] hover:bg-[#d4af37] text-slate-200 hover:text-[#05080f] border border-[#d4af37]/30 hover:border-[#d4af37] text-xs font-bold uppercase tracking-wider rounded-sm transition-all group/btn"
                  >
                    <span>Reservar</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Complimentary Amenities Banner */}
        <div className="mt-16 bg-gradient-to-r from-[#0f172a] via-[#162035] to-[#0f172a] border border-[#d4af37]/25 rounded-sm p-6 sm:p-8">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4 text-center sm:text-left">
              <div className="w-12 h-12 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/30 flex items-center justify-center text-[#d4af37] shrink-0">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-serif text-lg font-bold text-white">
                  O Padrão Biel de Conforto
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  Todos os atendimentos incluem comodidades exclusivas sem custo adicional.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full lg:w-auto">
              <div className="flex items-center gap-2.5 text-xs text-slate-300 bg-[#05080f]/60 px-4 py-2.5 rounded-sm border border-slate-800">
                <Coffee className="w-4 h-4 text-[#d4af37]" />
                <span className="font-medium">Café & Água</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs text-slate-300 bg-[#05080f]/60 px-4 py-2.5 rounded-sm border border-slate-800">
                <Wifi className="w-4 h-4 text-[#d4af37]" />
                <span className="font-medium">Wi-Fi Grátis</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
