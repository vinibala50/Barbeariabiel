import React from 'react';
import { Calendar, ArrowRight, Award, Star, Coffee, Sparkles, MapPin } from 'lucide-react';
import { SHOP_INFO } from '../data/barbershopData';

interface HeroProps {
  onBookClick: () => void;
  onExploreServices: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onBookClick, onExploreServices }) => {
  return (
    <section id="inicio" className="relative min-h-[95vh] flex items-center pt-28 pb-16 overflow-hidden">
      {/* Background with luxury gradient overlays */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-full lg:w-3/5 h-full opacity-35 lg:opacity-60 overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=1600&q=80"
            alt="Barbeiro profissional executando corte clássico"
            className="w-full h-full object-cover object-center filter contrast-110 saturate-90 scale-105 transition-transform duration-1000"
            loading="eager"
          />
          {/* Subtle gradient masks */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#05080f] via-transparent to-[#05080f]/50 lg:hidden" />
          <div className="absolute inset-0 hidden lg:block bg-gradient-to-r from-[#05080f] via-[#05080f]/40 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-b from-[#05080f]/40 via-transparent to-[#05080f]" />
        </div>

        {/* Ambient golden glow */}
        <div className="absolute -top-32 left-1/4 w-96 h-96 bg-[#d4af37]/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          <div className="lg:col-span-8">
            {/* Logo Badge & Tagline */}
            <div className="flex items-center gap-4 mb-6">
              <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-full p-0.5 bg-gradient-to-tr from-[#d4af37] via-[#f5d77f] to-[#aa841e] shadow-2xl shadow-[#d4af37]/30 shrink-0 group">
                <img
                  src={SHOP_INFO.logo}
                  alt="Brasão Barbearia Biel"
                  className="w-full h-full object-cover rounded-full group-hover:scale-105 transition-transform duration-500"
                />
              </div>

              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0f172a]/90 border border-[#d4af37]/35 text-[#d4af37] text-xs font-semibold uppercase tracking-[0.25em] shadow-lg backdrop-blur-sm">
                  <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
                  Alta Barbearia & Tradição
                </div>
                <span className="block text-[11px] uppercase tracking-[0.2em] text-slate-400 mt-1 font-medium">
                  Av. Guilherme Mankel, 630 · São Paulo
                </span>
              </div>
            </div>

            {/* Main Title */}
            <h1 className="font-serif text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white leading-[1.08] mb-6">
              Estilo & <span className="gold-gradient-text">Tradição</span>
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-xl text-slate-300 font-light leading-relaxed mb-8 max-w-xl">
              {SHOP_INFO.description}
            </p>

          {/* CTA Buttons */}
          <div className="flex flex-wrap items-center gap-4 mb-12">
            <button
              onClick={onBookClick}
              className="inline-flex items-center justify-center gap-3 px-7 py-4 bg-gradient-to-r from-[#d4af37] via-[#e2c158] to-[#aa841e] text-[#05080f] font-bold text-sm tracking-wider uppercase rounded-sm shadow-xl hover:shadow-[#d4af37]/40 hover:-translate-y-0.5 transition-all group"
            >
              <Calendar className="w-4 h-4 text-[#05080f]" />
              Agende seu Horário
              <ArrowRight className="w-4 h-4 text-[#05080f] group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={onExploreServices}
              className="inline-flex items-center justify-center gap-2 px-6 py-4 bg-[#0f172a]/80 hover:bg-[#162035] text-slate-200 hover:text-[#d4af37] border border-[#d4af37]/30 hover:border-[#d4af37] font-semibold text-sm tracking-wider uppercase rounded-sm transition-all backdrop-blur-sm"
            >
              Ver Menu Completo
            </button>

            <a
              href="#localizacao"
              className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-[#d4af37] tracking-wider uppercase py-2 px-3 transition-colors"
            >
              <MapPin className="w-3.5 h-3.5 text-[#d4af37]" />
              <span>Av. Guilherme Mankel, 630</span>
            </a>
          </div>

          {/* Highlights / Badges Row */}
          <div className="pt-6 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded bg-[#0f172a] border border-[#d4af37]/25 flex items-center justify-center text-[#d4af37] shrink-0">
                <Star className="w-4 h-4 fill-[#d4af37] text-[#d4af37]" />
              </div>
              <div>
                <p className="text-sm font-bold text-white leading-tight">4.9 ★</p>
                <p className="text-[11px] text-slate-400 font-medium">10k+ Clientes</p>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded bg-[#0f172a] border border-[#d4af37]/25 flex items-center justify-center text-[#d4af37] shrink-0">
                <Award className="w-4 h-4 text-[#d4af37]" />
              </div>
              <div>
                <p className="text-sm font-bold text-white leading-tight">12 Anos</p>
                <p className="text-[11px] text-slate-400 font-medium">De Tradição</p>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded bg-[#0f172a] border border-[#d4af37]/25 flex items-center justify-center text-[#d4af37] shrink-0">
                <Coffee className="w-4 h-4 text-[#d4af37]" />
              </div>
              <div>
                <p className="text-sm font-bold text-white leading-tight">Cortesia</p>
                <p className="text-[11px] text-slate-400 font-medium">Café & Água</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Hero Luxury Seal / Emblem */}
          <div className="hidden lg:flex lg:col-span-4 justify-center items-center">
            <div className="relative group">
              {/* Outer decorative gold ring */}
              <div className="absolute -inset-4 rounded-full border border-[#d4af37]/20 animate-pulse pointer-events-none" />
              <div className="absolute -inset-8 rounded-full border border-dashed border-[#d4af37]/15 pointer-events-none" />

              {/* Glowing backdrop */}
              <div className="absolute inset-0 rounded-full bg-[#d4af37]/20 blur-2xl group-hover:bg-[#d4af37]/35 transition-all" />

              {/* Main Circular Emblem */}
              <div className="relative w-72 h-72 xl:w-80 xl:h-80 rounded-full p-1.5 bg-gradient-to-b from-[#d4af37] via-[#aa841e] to-[#05080f] shadow-2xl shadow-black border-2 border-[#f5d77f]/60 group-hover:scale-105 transition-all duration-700">
                <img
                  src={SHOP_INFO.logo}
                  alt="Selo Oficial Barbearia Biel"
                  className="w-full h-full object-cover rounded-full"
                />
              </div>

              {/* Floating tag under medal */}
              <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 whitespace-nowrap px-4 py-1.5 rounded-full bg-[#0f172a] border border-[#d4af37]/60 shadow-xl text-[10px] font-bold uppercase tracking-widest text-[#f5d77f] flex items-center gap-1.5 backdrop-blur-md">
                <Star className="w-3 h-3 fill-[#d4af37] text-[#d4af37]" />
                Selo de Excelência Artesanal
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
