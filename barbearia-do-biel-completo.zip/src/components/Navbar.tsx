import React, { useState, useEffect } from 'react';
import { Scissors, Menu, X, Calendar, Clock, MapPin, Phone } from 'lucide-react';
import { SHOP_INFO } from '../data/barbershopData';

interface NavbarProps {
  onBookClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onBookClick }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Início', href: '#inicio' },
    { label: 'Serviços', href: '#servicos' },
    { label: 'Tradição', href: '#sobre' },
    { label: 'Portfólio', href: '#galeria' },
    { label: 'Depoimentos', href: '#depoimentos' },
    { label: 'Localização', href: '#localizacao' },
    { label: 'Contato', href: '#contato' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#05080f]/95 backdrop-blur-md py-3 border-b border-[#d4af37]/20 shadow-2xl'
          : 'bg-gradient-to-b from-[#05080f]/90 to-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a
            href="#inicio"
            className="flex items-center gap-3 group focus:outline-none"
            aria-label="Barbearia do Biel"
          >
            <div className="relative w-11 h-11 rounded-full overflow-hidden border border-[#d4af37]/60 group-hover:border-[#d4af37] shadow-lg shadow-[#d4af37]/15 group-hover:scale-105 transition-all bg-black shrink-0">
              <img
                src={SHOP_INFO.logo}
                alt="Logo Barbearia do Biel"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <span className="font-serif text-xl sm:text-2xl font-bold tracking-wider text-white">
                BARBEARIA <span className="text-[#d4af37]">BIEL</span>
              </span>
              <span className="block text-[9px] uppercase tracking-[0.25em] text-[#d4af37]/80 -mt-1 font-medium">
                Alta Barbearia & Tradição
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-xs uppercase tracking-[0.16em] text-slate-300 hover:text-[#d4af37] transition-colors font-medium py-1 relative group"
              >
                {link.label}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#d4af37] transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Desktop Right CTA */}
          <div className="hidden sm:flex items-center gap-4">
            <a
              href={`tel:${SHOP_INFO.phoneRaw}`}
              className="hidden xl:flex items-center gap-2 text-xs text-slate-300 hover:text-[#d4af37] transition-colors"
              title="Ligar para barbearia"
            >
              <Phone className="w-3.5 h-3.5 text-[#d4af37]" />
              <span>{SHOP_INFO.phoneDisplay}</span>
            </a>

            <button
              onClick={onBookClick}
              className="px-5 py-2.5 bg-gradient-to-r from-[#d4af37] to-[#aa841e] text-[#05080f] font-bold text-xs uppercase tracking-wider rounded-sm shadow-md hover:shadow-[#d4af37]/30 hover:scale-[1.02] active:scale-95 transition-all flex items-center gap-2"
            >
              <Calendar className="w-4 h-4" />
              Agendar Horário
            </button>
          </div>

          {/* Mobile Menu Trigger */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              onClick={onBookClick}
              className="px-3 py-1.5 bg-gradient-to-r from-[#d4af37] to-[#aa841e] text-[#05080f] font-bold text-[11px] uppercase tracking-wider rounded-sm"
            >
              Agendar
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-200 hover:text-[#d4af37] focus:outline-none"
              aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0a0f1d] border-b border-[#d4af37]/20 px-6 pt-4 pb-6 mt-3 shadow-2xl animate-in slide-in-from-top duration-200">
          <nav className="flex flex-col gap-3">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-sm uppercase tracking-wider text-slate-200 hover:text-[#d4af37] py-2 border-b border-slate-800/60"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="mt-5 pt-4 border-t border-slate-800 flex flex-col gap-3">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <MapPin className="w-4 h-4 text-[#d4af37]" />
              <span>{SHOP_INFO.address}</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Clock className="w-4 h-4 text-[#d4af37]" />
              <span>Seg a Sex: 10h às 20h | Sáb: 08h às 18h</span>
            </div>
            <a
              href={`https://wa.me/${SHOP_INFO.phoneRaw}?text=Ol%C3%A1%2C%20gostaria%20de%20agendar%20um%20hor%C3%A1rio%20na%20Barbearia%20do%20Biel.`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full mt-2 py-3 bg-[#d4af37] text-[#05080f] font-bold text-center uppercase tracking-wider text-xs rounded-sm"
              onClick={() => setMobileMenuOpen(false)}
            >
              Falar no WhatsApp
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
