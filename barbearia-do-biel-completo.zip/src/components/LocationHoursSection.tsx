import React, { useState } from 'react';
import { OPENING_HOURS, FAQS, SHOP_INFO } from '../data/barbershopData';
import {
  Clock,
  MapPin,
  Navigation,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  CheckCircle,
  HelpCircle,
  Car
} from 'lucide-react';

export const LocationHoursSection: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  // Check if currently open based on current day and time
  const isCurrentlyOpen = () => {
    const now = new Date();
    const day = now.getDay(); // 0 is Sunday, 1 is Monday, 2 is Tuesday, etc.
    const hour = now.getHours();

    // Monday (1) to Friday (5): 10:00 to 20:00
    if (day >= 1 && day <= 5) {
      return hour >= 10 && hour < 20;
    }
    // Saturday (6): 08:00 to 18:00
    if (day === 6) {
      return hour >= 8 && hour < 18;
    }
    // Sunday (0): closed
    return false;
  };

  const openNow = isCurrentlyOpen();

  return (
    <section id="localizacao" className="py-24 relative bg-[#0a0f1d] border-t border-[#d4af37]/15">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Row 1: Location & Hours */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 mb-20">
          {/* Left Column: Hours & Status */}
          <div className="lg:col-span-6 flex flex-col justify-between">
            <div>
              <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.3em] font-semibold text-[#d4af37] mb-3">
                <span className="w-8 h-px bg-[#d4af37]" />
                Atendimento
              </div>

              <div className="flex items-center gap-4 mb-6">
                <h2 className="font-serif text-3xl sm:text-4xl font-bold text-white tracking-tight">
                  Horários de <span className="gold-gradient-text">Funcionamento</span>
                </h2>

                <span
                  className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                    openNow
                      ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/40'
                      : 'bg-amber-950/80 text-amber-400 border border-amber-500/40'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      openNow ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
                    }`}
                  />
                  {openNow ? 'Aberto Agora' : 'Fechado no Momento'}
                </span>
              </div>

              {/* Hours Table */}
              <div className="bg-[#0f172a] border border-slate-800 rounded-sm overflow-hidden divide-y divide-slate-800/80 mb-6">
                {OPENING_HOURS.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-4 flex items-center justify-between text-xs sm:text-sm hover:bg-[#162035]/60 transition-colors"
                  >
                    <span className="font-semibold text-slate-200">{item.days}</span>
                    <span
                      className={
                        item.open
                          ? 'font-medium text-[#d4af37]'
                          : 'text-slate-500 italic'
                      }
                    >
                      {item.hours}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Address Banner */}
            <div className="bg-[#0f172a] border border-[#d4af37]/30 p-6 rounded-sm">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-sm bg-[#d4af37]/10 border border-[#d4af37]/40 flex items-center justify-center text-[#d4af37] shrink-0">
                  <MapPin className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <h3 className="font-serif text-lg font-bold text-white">
                    {SHOP_INFO.address}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    {SHOP_INFO.city} • Ponto de referência e estacionamento conveniente nas proximidades.
                  </p>

                  <div className="flex flex-wrap items-center gap-3 mt-4">
                    <a
                      href={SHOP_INFO.mapsQuery}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 bg-[#d4af37] text-[#05080f] font-bold text-xs uppercase tracking-wider rounded-sm hover:bg-[#aa841e] transition-colors"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      Google Maps
                    </a>

                    <a
                      href={SHOP_INFO.wazeQuery}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 bg-[#162035] text-slate-200 border border-slate-700 hover:border-[#d4af37] font-semibold text-xs uppercase tracking-wider rounded-sm transition-colors"
                    >
                      <Car className="w-3.5 h-3.5 text-[#d4af37]" />
                      Abrir no Waze
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Map / Ambiance Card */}
          <div className="lg:col-span-6">
            <div className="relative h-full min-h-[380px] rounded-sm overflow-hidden border border-[#d4af37]/30 bg-[#0f172a] shadow-2xl flex flex-col justify-end p-6 sm:p-8">
              <img
                src="https://images.unsplash.com/photo-1512690459411-b9245aed614b?auto=format&fit=crop&w=1000&q=80"
                alt="Fachada e atmosfera da Barbearia do Biel"
                className="absolute inset-0 w-full h-full object-cover filter contrast-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#05080f] via-[#05080f]/75 to-transparent" />

              <div className="relative z-10">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#d4af37]/20 border border-[#d4af37]/40 text-[#d4af37] text-[11px] font-bold uppercase tracking-wider rounded-xs mb-3 backdrop-blur-sm">
                  Espaço Exclusivo
                </div>
                <h3 className="font-serif text-2xl font-bold text-white mb-2">
                  Ambiente Acolhedor & Tradicional
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed max-w-lg mb-2">
                  Espaço pensado para o seu bem-estar e tranquilidade, com atendimento exclusivo e atencioso conduzido diretamente pelo Gabriel.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Row 2: Frequently Asked Questions */}
        <div className="pt-12 border-t border-slate-800">
          <div className="text-center max-w-xl mx-auto mb-10">
            <span className="text-[10px] uppercase tracking-[0.25em] text-[#d4af37] font-semibold block mb-1">
              Tire Suas Dúvidas
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white">
              Perguntas Frequentes
            </h3>
          </div>

          <div className="max-w-3xl mx-auto space-y-4">
            {FAQS.map((faq, idx) => (
              <div
                key={idx}
                className="bg-[#0f172a] border border-slate-800 rounded-sm overflow-hidden"
              >
                <button
                  onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                  className="w-full p-5 text-left flex items-center justify-between text-sm sm:text-base font-semibold text-white hover:text-[#d4af37] transition-colors"
                >
                  <span className="flex items-center gap-3">
                    <HelpCircle className="w-4 h-4 text-[#d4af37] shrink-0" />
                    {faq.q}
                  </span>
                  {openFaq === idx ? (
                    <ChevronUp className="w-5 h-5 text-[#d4af37] shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-slate-500 shrink-0" />
                  )}
                </button>

                {openFaq === idx && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-300 leading-relaxed border-t border-slate-800/60 animate-in fade-in">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
