import React, { useState } from 'react';
import { GALLERY_ITEMS } from '../data/barbershopData';
import { GalleryItem } from '../types';
import { ImageLightboxModal } from './ImageLightboxModal';
import { Maximize2, Sparkles } from 'lucide-react';

interface GallerySectionProps {
  onBookStyle: (item: GalleryItem) => void;
}

export const GallerySection: React.FC<GallerySectionProps> = ({ onBookStyle }) => {
  const [activeFilter, setActiveFilter] = useState<string>('todos');
  const [selectedItem, setSelectedItem] = useState<GalleryItem | null>(null);

  const filterOptions = [
    { id: 'todos', label: 'Todos' },
    { id: 'corte', label: 'Clássicos' },
    { id: 'fade', label: 'Degradê & Fade' },
    { id: 'barba', label: 'Barba Esculpida' },
    { id: 'navalha', label: 'Navalha Tradicional' },
  ];

  const filteredItems = activeFilter === 'todos'
    ? GALLERY_ITEMS
    : GALLERY_ITEMS.filter((item) => item.category === activeFilter);

  return (
    <section id="galeria" className="py-24 relative bg-[#05080f]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Intro */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.3em] font-semibold text-[#d4af37] mb-3">
              <span className="w-8 h-px bg-[#d4af37]" />
              Portfólio Real
            </div>
            <h2 className="font-serif text-3xl sm:text-5xl font-bold text-white tracking-tight">
              Galeria de <span className="gold-gradient-text">Resultados</span>
            </h2>
          </div>
          <p className="text-slate-400 max-w-sm text-sm leading-relaxed">
            A harmonia entre estética contemporânea e técnica tradicional executada em cada um de nossos clientes.
          </p>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-10 scrollbar-none">
          {filterOptions.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id)}
              className={`px-4 py-2 text-xs uppercase tracking-wider font-semibold rounded-sm transition-all ${
                activeFilter === filter.id
                  ? 'bg-[#d4af37] text-[#05080f] font-bold shadow-md'
                  : 'bg-[#0f172a] text-slate-300 hover:text-white border border-slate-800'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>

        {/* Editorial Layout Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-6">
          {filteredItems.map((item, idx) => {
            // Give specific column spans to create dynamic editorial rhythm
            let colSpanClass = 'lg:col-span-4';
            if (activeFilter === 'todos') {
              if (idx === 0) colSpanClass = 'lg:col-span-7 sm:col-span-2';
              else if (idx === 1) colSpanClass = 'lg:col-span-5';
              else if (idx === 2) colSpanClass = 'lg:col-span-5';
              else if (idx === 3) colSpanClass = 'lg:col-span-7 sm:col-span-2';
              else if (idx === 4) colSpanClass = 'lg:col-span-6';
              else if (idx === 5) colSpanClass = 'lg:col-span-6';
            }

            return (
              <div
                key={item.id}
                onClick={() => setSelectedItem(item)}
                className={`group relative h-80 sm:h-96 overflow-hidden rounded-sm border border-[#d4af37]/20 hover:border-[#d4af37] cursor-pointer bg-[#0f172a] shadow-xl transition-all duration-500 ${colSpanClass}`}
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-700 filter contrast-105"
                  loading="lazy"
                />

                {/* Dark Vignette Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#05080f]/95 via-[#05080f]/30 to-transparent opacity-80 group-hover:opacity-95 transition-opacity" />

                {/* Hover Quick Action Icon */}
                <div className="absolute top-4 right-4 w-9 h-9 rounded-full bg-[#05080f]/80 border border-[#d4af37]/40 flex items-center justify-center text-[#d4af37] opacity-0 group-hover:opacity-100 transition-opacity">
                  <Maximize2 className="w-4 h-4" />
                </div>

                {/* Captions */}
                <div className="absolute bottom-0 left-0 right-0 p-6 flex flex-col justify-end">
                  <span className="text-[10px] uppercase tracking-widest text-[#d4af37] font-semibold mb-1">
                    {item.category.toUpperCase()}
                  </span>
                  <h3 className="font-serif text-xl sm:text-2xl font-bold text-white group-hover:text-[#f5d77f] transition-colors mb-1">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-300 opacity-90 line-clamp-2">
                    {item.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Lightbox */}
        <ImageLightboxModal
          item={selectedItem}
          onClose={() => setSelectedItem(null)}
          onBookStyle={onBookStyle}
        />
      </div>
    </section>
  );
};
