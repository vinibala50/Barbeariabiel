/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ServicesSection } from './components/ServicesSection';
import { AboutSection } from './components/AboutSection';
import { GallerySection } from './components/GallerySection';
import { ReviewsSection } from './components/ReviewsSection';
import { BookingSection } from './components/BookingSection';
import { LocationHoursSection } from './components/LocationHoursSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Service, GalleryItem } from './types';
import { SERVICES } from './data/barbershopData';

export default function App() {
  const [selectedService, setSelectedService] = useState<Service | null>(null);

  const handleBookClick = () => {
    const el = document.getElementById('contato');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleExploreServices = () => {
    const el = document.getElementById('servicos');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectService = (service: Service) => {
    setSelectedService(service);
    const el = document.getElementById('contato');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleBookStyle = (item: GalleryItem) => {
    // Match appropriate service based on style category
    if (item.category === 'barba') {
      const barba = SERVICES.find((s) => s.id === 'barba-tradicional') || SERVICES[1];
      setSelectedService(barba);
    } else if (item.category === 'navalha') {
      const combo = SERVICES.find((s) => s.category === 'combo') || SERVICES[3];
      setSelectedService(combo);
    } else {
      const corte = SERVICES.find((s) => s.id === 'corte-masculino') || SERVICES[0];
      setSelectedService(corte);
    }
    const el = document.getElementById('contato');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#05080f] text-[#f8f6f0] selection:bg-[#d4af37] selection:text-[#05080f]">
      {/* Fixed Navbar */}
      <Navbar onBookClick={handleBookClick} />

      <main>
        {/* Hero Section */}
        <Hero
          onBookClick={handleBookClick}
          onExploreServices={handleExploreServices}
        />

        {/* Services & Menu */}
        <ServicesSection onSelectService={handleSelectService} />

        {/* About & Craftsmanship */}
        <AboutSection />

        {/* Editorial Photo Gallery */}
        <GallerySection onBookStyle={handleBookStyle} />

        {/* Customer Reviews & Feedback */}
        <ReviewsSection />

        {/* Interactive Booking & WhatsApp Scheduler */}
        <BookingSection selectedServicePreload={selectedService} />

        {/* Location, Opening Hours & FAQ */}
        <LocationHoursSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating WhatsApp Action Button */}
      <FloatingWhatsApp />
    </div>
  );
}
