export interface Service {
  id: string;
  name: string;
  category: 'corte' | 'barba' | 'tratamento' | 'combo';
  price: number;
  durationMinutes: number;
  description: string;
  image: string;
  popular?: boolean;
}

export interface Barber {
  id: string;
  name: string;
  role: string;
  specialty: string;
  experience: string;
  photo: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'corte' | 'barba' | 'fade' | 'navalha';
  image: string;
  description: string;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  date: string;
  comment: string;
  verified: boolean;
  avatar?: string;
}

export interface BookingState {
  serviceId: string;
  barberId: string;
  date: string;
  timeSlot: string;
  clientName: string;
  clientPhone: string;
  notes: string;
}
