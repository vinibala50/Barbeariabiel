import { Service, Barber, GalleryItem, Review } from '../types';

export const SHOP_INFO = {
  name: 'Barbearia do Biel',
  shortName: 'BIEL · BARBER',
  logo: '/assets/aistudio/0F3442A8-D816-4F77-B569-9B90535319D2_8588dade.png',
  tagline: 'Estilo, Tradição e Excelência',
  description: 'O ritual clássico do cuidado masculino elevado à sua máxima potência. Precisão na navalha, corte sob medida e conforto absoluto.',
  address: 'Avenida Guilherme Mankel, 630',
  city: 'São Paulo - SP',
  phoneDisplay: '(11) 98303-6194',
  phoneRaw: '5511983036194',
  rating: 4.9,
  reviewsCount: '10.000+',
  yearsExperience: '12 anos',
  mapsQuery: 'https://www.google.com/maps/search/?api=1&query=Avenida+Guilherme+Mankel+630+Sao+Paulo',
  wazeQuery: 'https://waze.com/ul?q=Avenida%20Guilherme%20Mankel%20630%20Sao%20Paulo'
};

export const SERVICES: Service[] = [
  {
    id: 'corte-masculino',
    name: 'Corte Masculino',
    category: 'corte',
    price: 40,
    durationMinutes: 40,
    description: 'Máquina, tesoura e navalha.',
    image: 'https://images.unsplash.com/photo-1622286342621-4bd786c2447c?auto=format&fit=crop&w=800&q=80',
    popular: true
  },
  {
    id: 'barba-tradicional',
    name: 'Barba Tradicional',
    category: 'barba',
    price: 40,
    durationMinutes: 35,
    description: 'Barboterapia com óleos essenciais nutritivos, navalhete descartável e hidratação calmante pós-barba.',
    image: 'https://images.unsplash.com/photo-1599351431202-1e0f0137899a?auto=format&fit=crop&w=800&q=80',
    popular: true
  },
  {
    id: 'sobrancelha-navalha',
    name: 'Sobrancelha na Navalha',
    category: 'corte',
    price: 10,
    durationMinutes: 15,
    description: 'Alinhamento natural da sobrancelha na navalha clássica, mantendo a proporção facial masculina e acabamento limpo.',
    image: 'https://images.unsplash.com/photo-1593702295094-aea22597af65?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'combo-cabelo-barba-sobrancelha',
    name: 'Cabelo + Barba + Sobrancelha (Combo Especial)',
    category: 'combo',
    price: 80,
    durationMinutes: 65,
    description: 'Pacote completo: corte com máquina, tesoura e navalha, barba alinhada com hidratação e acabamento de sobrancelha na navalha.',
    image: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=800&q=80',
    popular: true
  }
];

export const BARBERS: Barber[] = [
  {
    id: 'gabriel',
    name: 'Gabriel',
    role: 'Fundador',
    specialty: 'Cortes clássicos, máquina, tesoura, navalha e visagismo',
    experience: '12 anos',
    photo: '/assets/aistudio/IMG_9922_a90f8a8d.jpeg'
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Linhas Clássicas',
    category: 'corte',
    image: 'https://images.unsplash.com/photo-1512690459411-b9245aed614b?auto=format&fit=crop&w=900&q=80',
    description: 'Penteado clássico com divisão lateral e brilho acetinado.'
  },
  {
    id: 'gal-2',
    title: 'Barba Esculpida',
    category: 'barba',
    image: 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=800&q=80',
    description: 'Contorno de maxilar perfeitamente desenhado e alinhamento na navalha.'
  },
  {
    id: 'gal-3',
    title: 'Degradê Milimétrico (Fade)',
    category: 'fade',
    image: 'https://images.unsplash.com/photo-1593702295094-aea22597af65?auto=format&fit=crop&w=800&q=80',
    description: 'Transição suave da lâmina à tesoura, acabamento impecável.'
  },
  {
    id: 'gal-4',
    title: 'Navalha Tradicional & Acabamento',
    category: 'navalha',
    image: 'https://images.unsplash.com/photo-1503951458645-643d53bfd90f?auto=format&fit=crop&w=1000&q=80',
    description: 'Técnica de barbear clássico com navalha esterilizada e hidratação profunda.'
  },
  {
    id: 'gal-5',
    title: 'Textura & Movimento',
    category: 'corte',
    image: 'https://images.unsplash.com/photo-1605497788044-5a32c7078486?auto=format&fit=crop&w=800&q=80',
    description: 'Corte moderno texturizado no topo com acabamento fosco natural.'
  },
  {
    id: 'gal-6',
    title: 'Barba Rústica & Bigode Alinhado',
    category: 'barba',
    image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=800&q=80',
    description: 'Barba volumosa bem alinhada e bigode esculpido com precisão artesanal.'
  }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    author: 'Rodrigo',
    rating: 5,
    date: 'Há 3 dias',
    comment: 'O Gabriel manda muito bem no corte! Atendimento excelente, ambiente organizado e muito agradável. Com certeza voltarei mais vezes. Recomendo demais!',
    verified: true
  },
  {
    id: 'rev-2',
    author: 'Vinícius',
    rating: 5,
    date: 'Há 1 semana',
    comment: 'Barbearia top! Além do ótimo serviço do Gabriel, ainda tem café e água grátis para os clientes. Dá para ver o cuidado com cada detalhe. Experiência muito boa!',
    verified: true
  },
  {
    id: 'rev-3',
    author: 'Lucas',
    rating: 5,
    date: 'Há 2 semanas',
    comment: 'Lugar muito bom para cortar o cabelo! Tem Wi-Fi grátis, som ambiente e um clima tranquilo. O Gabriel é atencioso e capricha no corte. Vale a pena conhecer!',
    verified: true
  },
  {
    id: 'rev-4',
    author: 'Felipe',
    rating: 5,
    date: 'Há 3 semanas',
    comment: 'Gostei bastante da barbearia! O atendimento é diferenciado, o espaço é confortável e o Gabriel trabalha muito bem. É aquele lugar onde você se sente à vontade e sai satisfeito com o resultado.',
    verified: true
  }
];

export const TIME_SLOTS = [
  '08:00', '09:00', '10:00', '10:45', '11:30', '12:15',
  '13:30', '14:15', '15:00', '15:45', '16:30',
  '17:15', '18:00', '18:45', '19:15'
];

export const OPENING_HOURS = [
  { days: 'Segunda a Sexta-feira', hours: '10:00 às 20:00', open: true },
  { days: 'Sábado', hours: '08:00 às 18:00', open: true },
  { days: 'Domingo', hours: 'Fechado', open: false }
];

export const FAQS = [
  {
    q: 'Preciso agendar com antecedência?',
    a: 'Recomendamos o agendamento prévio pelo nosso WhatsApp para garantir seu horário sem espera, mas também atendemos por ordem de chegada havendo encaixe.'
  },
  {
    q: 'Quais formas de pagamento são aceitas?',
    a: 'Aceitamos PIX, cartões de crédito e débito (todas as bandeiras) e dinheiro.'
  },
  {
    q: 'Vocês oferecem bebidas cortesia?',
    a: 'Sim! Todos os nossos clientes têm direito a café fresquinho e água mineral gelada à vontade durante o atendimento, além de Wi-Fi grátis.'
  },
  {
    q: 'Onde a barbearia está localizada?',
    a: 'Estamos na Avenida Guilherme Mankel, 630, em São Paulo - SP, com fácil acesso e vagas de estacionamento nas imediações.'
  }
];
