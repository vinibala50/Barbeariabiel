# Barbearia do Biel — Site Oficial

Website premium da **Barbearia do Biel**, desenvolvido com React, TypeScript, Tailwind CSS e ícones Lucide.

## 🚀 Como Executar Localmente

1. Extraia os arquivos e abra o terminal na pasta do projeto:
   ```bash
   npm install
   ```

2. Inicie o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```

3. Para gerar a versão de produção:
   ```bash
   npm run build
   ```

---

## 🌐 Como Hospedar na Netlify

### Opção 1: Netlify Drop (Mais Fácil - Sem Terminal)
1. Acesse [app.netlify.com/drop](https://app.netlify.com/drop)
2. Descompacte o arquivo `barbearia-do-biel-site-pronto.zip` (ou arraste a pasta `dist`)
3. Arraste a pasta descompactada para o navegador. Seu site estará no ar em poucos segundos!

### Opção 2: Conectando com GitHub / Lovable
Se você importar o projeto para o GitHub:
- **Build command**: `npm run build`
- **Publish directory**: `dist`

---

## 💈 Informações da Barbearia
- **Endereço**: Avenida Guilherme Mankel, 630 - São Paulo, SP
- **Telefone / WhatsApp**: (11) 98303-6194
- **Horário de Atendimento**:
  - Segunda a Sexta: 10:00 às 20:00
  - Sábado: 08:00 às 18:00
  - Domingo: Fechado
- **Cortesias**: Café, Água e Wi-Fi Grátis
